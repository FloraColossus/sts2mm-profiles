# Deck Builder

1. Download the latest release.
2. Copy the `DeckBuilder` folder (containing `DeckBuilder.dll` and `DeckBuilder.json`) into the `mods` folder in the root of your Slay the Spire 2 installation:
   ```
   <Slay the Spire 2>/mods/DeckBuilder/
   ├── DeckBuilder.dll
   └── DeckBuilder.json
   ```
3. Launch the game and enable **Deck Builder** from the mod menu.